/*
 *	$Source: /u1/X/libis/RCS/is-copyright.h,v $
 *	$Header: is-copyright.h,v 1.1 86/11/17 14:34:59 swick Rel $
 */

    /*

    Copyright (c) 1986, Integrated Solutions, Inc.

    The Integrated Solutions X driver is a product of Integrated
    Solutions, Inc.  Permission to use, copy, modify, and distribute
    this software and its documentation for any purpose and without fee
    is hereby granted, provided that the above copyright notice appear
    in all copies and that both that copyright notice and this
    permission notice appear in supporting documentation, and that the
    name of Integrated Solutions not be used in advertising or
    publicity pertaining to distribution of the software without
    specific, written prior permission.  Integrated Solutions makes no
    representations about the suitability of this software for any
    purpose.  It is provided "as is" without express or implied
    warranty.

    Integrated Solutions, Inc.
    1140 Ringwood Court
    San Jose, California  95131
    (408) 943-1902

    */
