#include "vssite.h"

char *ddxfontdir = DEFAULT_FONT_DIRECTORY;
char *ddxfontsuffix = DEFAULT_FONT_SUFFIX;
