#ifdef KEYBD
	/*
	 * This is the directory where keyboard mapping can be found
	 */
#define	KEYBDDIR	"/lib/X/keybd/"
#endif KEYBD
	/*
	 * This is the default Xdefaults file
	 */
#define	XDEFAULTS	"/lib/X/Xdefaults"
