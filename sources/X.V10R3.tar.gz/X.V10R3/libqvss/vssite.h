/* vssite.h
**
** This is where any machine or display specific information should
** be stored so that different sites can have control over where things live.
**
*/

#define DEFAULT_FONT_DIRECTORY	"/usr/new/lib/X/font/"
#define DEFAULT_FONT_SUFFIX	".onx"

